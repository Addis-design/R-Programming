library(expm)
mat1<-matrix(c(.5,.5,.25,.75),2,byrow = T)
mat2<-matrix(c(.33,.67,.67,.33),2,byrow = T)
matresults=mat1%*%mat2
matresults




