library(expm)
mat1<-matrix(c(.5,.5,.25,.75),2,byrow = T)
matresults=mat1%^%3
matresults




